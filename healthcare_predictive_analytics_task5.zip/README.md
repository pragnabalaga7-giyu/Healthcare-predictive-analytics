# Healthcare Predictive Analytics – Task 5

## Project Title
**Disease Prediction Using Healthcare Data**

## Objective
Build and evaluate a basic predictive analytics model using historical healthcare data. This project predicts whether a patient is at higher risk of disease using demographic, clinical and lifestyle variables.

## Problem Selected
**Disease prediction**

## Tools Used
- Python
- Pandas
- Scikit-learn
- Logistic Regression
- StandardScaler
- Train/Test Split
- Accuracy, Precision, Recall and F1-score

## Dataset
The dataset contains 300 **synthetic** patient records. It includes:
- Age
- BMI
- Blood pressure
- Glucose level
- Smoking status
- Physical activity
- Disease outcome

`Disease = 1` indicates the simulated disease outcome and `0` indicates no disease.

> This dataset is synthetic and is intended only for educational/project demonstration. It must not be used for clinical decisions.

## Workflow
1. Data collection
2. Data preprocessing
3. Model building
4. Model evaluation
5. Prediction and insights

## Model
A **Logistic Regression** classifier is used because disease prediction is a binary classification problem.

## Results
Using an 80/20 train-test split (random state = 42):

- Accuracy: **0.817**
- Precision: **0.667**
- Recall: **0.533**
- F1 Score: **0.593**

Confusion matrix:
```
[[41  4]
 [ 7  8]]
```

## Key Insights
- Age, BMI, blood pressure and glucose contribute to the predicted disease risk.
- Smoking status is included as a lifestyle risk factor.
- Physical activity is included as a protective lifestyle variable.
- Logistic regression provides a simple and interpretable baseline model.

## How to Run
```bash
pip install -r requirements.txt
python disease_prediction.py
```

## GitHub Submission
Upload the complete project folder to a GitHub repository named something like:

`healthcare-predictive-analytics-task5`

Include:
- `data/healthcare_disease_prediction.csv`
- `disease_prediction.py`
- `README.md`
- `requirements.txt`

## Disclaimer
This is an educational predictive analytics project using synthetic data. It is not a medical diagnostic system.
